package com.fitness.motivator.ui;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.fitness.motivator.R;
import com.fitness.motivator.utils.TaskManager;

/**
 * شاشة الحجب الكاملة — تظهر فوق التطبيق المحجوب وتمنع استخدامه
 * حتى يكمل المستخدم جميع مهامه اليومية.
 */
public class OverlayActivity extends AppCompatActivity {

    private TaskManager taskManager;
    private Handler refreshHandler;
    private Runnable refreshRunnable;

    // رسائل تحفيزية عشوائية
    private static final String[] MOTIVATIONS = {
        "💪 جسمك يستحق اهتمامك أكثر من هذا التطبيق!",
        "🏃 30 دقيقة رياضة تساوي ساعات من السعادة",
        "🥗 كل وجبة صحية خطوة نحو نسختك الأفضل",
        "🎯 الانضباط اليوم يصنع النجاح غداً",
        "⚡ أنت أقوى من أي إدمان على التطبيقات!",
        "🌟 العادات الصحية تبنى يوماً بيوم",
        "🔥 لا تستسلم، أنت على بُعد خطوات من هدفك!"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // جعل الشاشة فوق كل شيء
        getWindow().addFlags(
            WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED |
            WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON  |
            WindowManager.LayoutParams.FLAG_FULLSCREEN
        );

        setContentView(R.layout.activity_overlay);

        taskManager = new TaskManager(this);

        String blockedPackage = getIntent().getStringExtra("blocked_package");
        populateUI(blockedPackage);
        startAutoCheck();
    }

    // ─── تعبئة واجهة الشاشة ─────────────────────────────────────────────

    private void populateUI(String blockedPackage) {
        TextView tvBlockedApp    = findViewById(R.id.tvBlockedApp);
        TextView tvMotivation    = findViewById(R.id.tvMotivation);
        ProgressBar progressBar  = findViewById(R.id.overlayProgress);
        TextView tvProgressText  = findViewById(R.id.tvOverlayProgress);
        TextView tvTaskSummary   = findViewById(R.id.tvTaskSummary);
        Button   btnGoToTasks    = findViewById(R.id.btnGoToTasks);
        Button   btnGoHome       = findViewById(R.id.btnGoHome);

        // اسم التطبيق المحجوب
        String appName = resolveAppName(blockedPackage);
        tvBlockedApp.setText("🔒 " + appName + " محجوب الآن");

        // رسالة تحفيزية عشوائية
        int idx = (int) (Math.random() * MOTIVATIONS.length);
        tvMotivation.setText(MOTIVATIONS[idx]);

        // شريط التقدم
        int pct = taskManager.getCompletionPercentage();
        progressBar.setProgress(pct);
        tvProgressText.setText("أنجزت " + pct + "% من مهامك اليومية");

        // المهام المتبقية
        StringBuilder sb = new StringBuilder("المهام المتبقية:\n");
        for (TaskManager.Task task : taskManager.getTasks()) {
            if (!task.completed) {
                sb.append("• ").append(task.title).append("\n");
            }
        }
        tvTaskSummary.setText(sb.toString().trim());

        // زر: الذهاب لقائمة المهام
        btnGoToTasks.setOnClickListener(v -> {
            Intent intent = new Intent(this, MainActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent);
            finish();
        });

        // زر: الشاشة الرئيسية
        btnGoHome.setOnClickListener(v -> goHome());
    }

    // ─── مراقبة تلقائية كل ثانيتين ──────────────────────────────────────

    private void startAutoCheck() {
        refreshHandler  = new Handler(Looper.getMainLooper());
        refreshRunnable = new Runnable() {
            @Override
            public void run() {
                taskManager = new TaskManager(OverlayActivity.this);
                if (taskManager.areAllTasksCompleted()) {
                    showSuccessAndDismiss();
                } else {
                    // تحديث شريط التقدم في الوقت الفعلي
                    ProgressBar pb = findViewById(R.id.overlayProgress);
                    TextView tv    = findViewById(R.id.tvOverlayProgress);
                    if (pb != null && tv != null) {
                        int pct = taskManager.getCompletionPercentage();
                        pb.setProgress(pct);
                        tv.setText("أنجزت " + pct + "% من مهامك اليومية");
                    }
                    refreshHandler.postDelayed(this, 2000);
                }
            }
        };
        refreshHandler.postDelayed(refreshRunnable, 2000);
    }

    private void showSuccessAndDismiss() {
        TextView tvBlockedApp = findViewById(R.id.tvBlockedApp);
        if (tvBlockedApp != null) {
            tvBlockedApp.setText("✅ رائع! كل المهام مكتملة\nالتطبيق مفتوح الآن 🎉");
        }
        new Handler(Looper.getMainLooper()).postDelayed(this::finish, 2000);
    }

    // ─── منع العودة للتطبيق المحجوب ─────────────────────────────────────

    @Override
    public void onBackPressed() {
        goHome(); // بدل العودة، نذهب للشاشة الرئيسية
    }

    private void goHome() {
        Intent homeIntent = new Intent(Intent.ACTION_MAIN);
        homeIntent.addCategory(Intent.CATEGORY_HOME);
        homeIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(homeIntent);
        finish();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (refreshHandler != null && refreshRunnable != null) {
            refreshHandler.removeCallbacks(refreshRunnable);
        }
    }

    // ─── تحويل package name لاسم مقروء ─────────────────────────────────

    private String resolveAppName(String pkg) {
        if (pkg == null) return "التطبيق";
        switch (pkg) {
            case "com.facebook.katana":
            case "com.facebook.lite":         return "Facebook";
            case "com.zhiliaoapp.musically":
            case "com.ss.android.ugc.trill":  return "TikTok";
            case "com.instagram.android":     return "Instagram";
            case "com.twitter.android":
            case "com.twitter.lite":          return "Twitter / X";
            case "com.snapchat.android":      return "Snapchat";
            case "com.whatsapp":              return "WhatsApp";
            case "com.telegram.messenger":    return "Telegram";
            case "com.youtube.android":
            case "com.google.android.youtube":return "YouTube";
            default:
                int dot = pkg.lastIndexOf('.');
                return dot >= 0 ? pkg.substring(dot + 1) : pkg;
        }
    }
}
