package com.fitness.motivator.service;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.util.Log;

/**
 * يُشغّل خدمة المراقبة تلقائياً بعد إعادة تشغيل الجهاز.
 * يحتاج صلاحية RECEIVE_BOOT_COMPLETED في الـ Manifest.
 */
public class BootReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        if (!Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) return;

        Log.d("BootReceiver", "جهاز أُعيد تشغيله — تشغيل AppMonitorService");

        Intent serviceIntent = new Intent(context, AppMonitorService.class);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(serviceIntent);
        } else {
            context.startService(serviceIntent);
        }
    }
}
