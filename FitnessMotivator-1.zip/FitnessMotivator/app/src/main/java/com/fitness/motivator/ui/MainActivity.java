package com.fitness.motivator.ui;

import android.app.AppOpsManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.fitness.motivator.R;
import com.fitness.motivator.service.AppMonitorService;
import com.fitness.motivator.utils.TaskManager;

import java.util.stream.Collectors;

/**
 * الشاشة الرئيسية — تعرض قائمة المهام اليومية وحالة الحراسة
 */
public class MainActivity extends AppCompatActivity {

    private TaskManager taskManager;
    private TaskAdapter taskAdapter;
    private ProgressBar progressBar;
    private TextView tvProgress;
    private TextView tvStatus;
    private Button btnToggleService;
    private View cardPermissions;
    private TextView tvUsageStatus;
    private TextView tvOverlayStatus;
    private Button btnUsageAccess;
    private Button btnOverlayAccess;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        taskManager = new TaskManager(this);
        bindViews();
        setupListeners();
    }

    @Override
    protected void onResume() {
        super.onResume();
        checkPermissions();
        refreshUI();
    }

    private void bindViews() {
        progressBar      = findViewById(R.id.progressBar);
        tvProgress       = findViewById(R.id.tvProgress);
        tvStatus         = findViewById(R.id.tvStatus);
        btnToggleService = findViewById(R.id.btnToggleService);
        cardPermissions  = findViewById(R.id.cardPermissions);
        tvUsageStatus    = findViewById(R.id.tvUsageStatus);
        tvOverlayStatus  = findViewById(R.id.tvOverlayStatus);
        btnUsageAccess   = findViewById(R.id.btnUsageAccess);
        btnOverlayAccess = findViewById(R.id.btnOverlayAccess);

        RecyclerView recyclerView = findViewById(R.id.recyclerTasks);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setNestedScrollingEnabled(false);

        taskAdapter = new TaskAdapter(taskManager.getTasks(), (taskId, isChecked) -> {
            taskManager.setTaskCompleted(taskId, isChecked);
            refreshUI();
        });
        recyclerView.setAdapter(taskAdapter);
    }

    private void setupListeners() {
        btnToggleService.setOnClickListener(v -> toggleService());

        btnUsageAccess.setOnClickListener(v ->
            startActivity(new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
        );

        btnOverlayAccess.setOnClickListener(v -> {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                Intent intent = new Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName())
                );
                startActivity(intent);
            }
        });
    }

    private void refreshUI() {
        taskManager = new TaskManager(this);
        taskAdapter.updateTasks(taskManager.getTasks());

        int pct = taskManager.getCompletionPercentage();
        progressBar.setProgress(pct);
        tvProgress.setText(pct + "%");

        if (taskManager.areAllTasksCompleted()) {
            tvStatus.setText("🎉 أحسنت! كل المهام مكتملة — التطبيقات مفتوحة الآن");
            tvStatus.setBackgroundResource(R.drawable.bg_status_success);
        } else {
            int done  = 0;
            for (TaskManager.Task t : taskManager.getTasks()) {
                if (t.completed) done++;
            }
            int total = taskManager.getTasks().size();
            tvStatus.setText("🔒 " + done + "/" + total + " مهام — التطبيقات محجوبة");
            tvStatus.setBackgroundResource(R.drawable.bg_status_locked);
        }

        boolean running = AppMonitorService.isRunning;
        btnToggleService.setText(running ? "⏹ إيقاف الحراسة" : "▶ تشغيل الحراسة");
        btnToggleService.setBackgroundTintList(
            getColorStateList(running ? R.color.colorStop : R.color.colorStart)
        );
    }

    private void toggleService() {
        Intent svc = new Intent(this, AppMonitorService.class);

        if (AppMonitorService.isRunning) {
            stopService(svc);
            AppMonitorService.isRunning = false;
            Toast.makeText(this, "تم إيقاف الحراسة", Toast.LENGTH_SHORT).show();
            refreshUI();
            return;
        }

        if (!hasUsageStatsPermission() || !hasOverlayPermission()) {
            showPermissionsDialog();
            return;
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(svc);
        } else {
            startService(svc);
        }
        Toast.makeText(this, "✅ تم تشغيل الحراسة", Toast.LENGTH_SHORT).show();
        refreshUI();
    }

    private void checkPermissions() {
        boolean hasUsage   = hasUsageStatsPermission();
        boolean hasOverlay = hasOverlayPermission();

        cardPermissions.setVisibility((hasUsage && hasOverlay) ? View.GONE : View.VISIBLE);
        tvUsageStatus.setText(hasUsage    ? "✅ مُمنوحة" : "❌ مطلوبة");
        tvOverlayStatus.setText(hasOverlay ? "✅ مُمنوحة" : "❌ مطلوبة");
        btnUsageAccess.setEnabled(!hasUsage);
        btnOverlayAccess.setEnabled(!hasOverlay);

        if (hasUsage && hasOverlay && !AppMonitorService.isRunning) {
            Intent svc = new Intent(this, AppMonitorService.class);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(svc);
            } else {
                startService(svc);
            }
        }
    }

    private boolean hasUsageStatsPermission() {
        try {
            AppOpsManager appOps =
                (AppOpsManager) getSystemService(Context.APP_OPS_SERVICE);
            int mode = appOps.checkOpNoThrow(
                AppOpsManager.OPSTR_GET_USAGE_STATS,
                android.os.Process.myUid(),
                getPackageName()
            );
            return mode == AppOpsManager.MODE_ALLOWED;
        } catch (Exception e) {
            return false;
        }
    }

    private boolean hasOverlayPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            return Settings.canDrawOverlays(this);
        }
        return true;
    }

    private void showPermissionsDialog() {
        new AlertDialog.Builder(this)
            .setTitle("🔐 صلاحيات مطلوبة")
            .setMessage(
                "لكي يعمل التطبيق يحتاج صلاحيتين:\n\n" +
                "1️⃣ إحصائيات الاستخدام\n" +
                "   ← لمعرفة التطبيق المفتوح\n\n" +
                "2️⃣ الظهور فوق التطبيقات\n" +
                "   ← لعرض شاشة التنبيه\n\n" +
                "يرجى منحهما من أزرار أعلاه ثم تشغيل الحراسة."
            )
            .setPositiveButton("فهمت", null)
            .show();
    }
}
