package com.fitness.motivator.utils;

import android.content.Context;
import android.content.SharedPreferences;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * يدير المهام اليومية باستخدام SharedPreferences.
 * تُعاد المهام للصفر تلقائياً مع بداية كل يوم جديد.
 */
public class TaskManager {

    private static final String PREFS_NAME        = "fitness_tasks";
    private static final String KEY_DATE          = "task_date";
    private static final String KEY_TASK_COUNT    = "task_count";
    private static final String PREFIX_TITLE      = "task_title_";
    private static final String PREFIX_DONE       = "task_done_";

    // المهام الافتراضية اليومية
    private static final String[] DEFAULT_TASKS = {
        "ممارسة الرياضة (30 دقيقة على الأقل) 🏃",
        "الالتزام بالرجيم وتجنب الوجبات الضارة 🥗",
        "شرب 8 أكواب ماء 💧",
        "النوم المبكر قبل الساعة 11 مساءً 🌙"
    };

    /** نموذج المهمة */
    public static class Task {
        public final int    id;
        public final String title;
        public boolean      completed;

        public Task(int id, String title, boolean completed) {
            this.id        = id;
            this.title     = title;
            this.completed = completed;
        }
    }

    private final SharedPreferences prefs;
    private final String            todayDate;

    public TaskManager(Context context) {
        prefs     = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        todayDate = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());
        ensureTodayTasksExist();
    }

    // ─── تهيئة المهام ───────────────────────────────────────────────────

    /**
     * إذا كان اليوم جديداً (أو أول تشغيل)، أنشئ مهام جديدة من الافتراضية.
     */
    private void ensureTodayTasksExist() {
        String savedDate = prefs.getString(KEY_DATE, "");
        if (!savedDate.equals(todayDate)) {
            SharedPreferences.Editor ed = prefs.edit();
            ed.putString(KEY_DATE,     todayDate);
            ed.putInt(KEY_TASK_COUNT,  DEFAULT_TASKS.length);
            for (int i = 0; i < DEFAULT_TASKS.length; i++) {
                ed.putString(PREFIX_TITLE + i, DEFAULT_TASKS[i]);
                ed.putBoolean(PREFIX_DONE  + i, false);
            }
            ed.apply();
        }
    }

    // ─── عمليات المهام ──────────────────────────────────────────────────

    /** جلب كل مهام اليوم */
    public List<Task> getTasks() {
        int count = prefs.getInt(KEY_TASK_COUNT, 0);
        List<Task> list = new ArrayList<>(count);
        for (int i = 0; i < count; i++) {
            String  title = prefs.getString(PREFIX_TITLE + i, "");
            boolean done  = prefs.getBoolean(PREFIX_DONE  + i, false);
            list.add(new Task(i, title, done));
        }
        return list;
    }

    /** تحديد مهمة كمكتملة أو غير مكتملة */
    public void setTaskCompleted(int taskId, boolean completed) {
        prefs.edit()
             .putBoolean(PREFIX_DONE + taskId, completed)
             .apply();
    }

    /**
     * هل اكتملت جميع المهام؟
     * إذا نعم → رفع الحجب عن التطبيقات
     */
    public boolean areAllTasksCompleted() {
        List<Task> tasks = getTasks();
        if (tasks.isEmpty()) return true;
        for (Task t : tasks) {
            if (!t.completed) return false;
        }
        return true;
    }

    /**
     * نسبة الإنجاز من 0 إلى 100
     */
    public int getCompletionPercentage() {
        List<Task> tasks = getTasks();
        if (tasks.isEmpty()) return 100;
        int done = 0;
        for (Task t : tasks) {
            if (t.completed) done++;
        }
        return (done * 100) / tasks.size();
    }
}
