package com.fitness.motivator.ui;

import android.graphics.Paint;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.fitness.motivator.R;
import com.fitness.motivator.utils.TaskManager;

import java.util.List;

/**
 * Adapter لقائمة المهام اليومية (RecyclerView)
 */
public class TaskAdapter extends RecyclerView.Adapter<TaskAdapter.TaskViewHolder> {

    /** واجهة callback عند تغيير حالة المهمة */
    public interface OnTaskChangedListener {
        void onTaskChanged(int taskId, boolean isCompleted);
    }

    private List<TaskManager.Task>   tasks;
    private final OnTaskChangedListener listener;

    public TaskAdapter(List<TaskManager.Task> tasks, OnTaskChangedListener listener) {
        this.tasks    = tasks;
        this.listener = listener;
    }

    /** تحديث القائمة بالكامل */
    public void updateTasks(List<TaskManager.Task> newTasks) {
        this.tasks = newTasks;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public TaskViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                               .inflate(R.layout.item_task, parent, false);
        return new TaskViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull TaskViewHolder holder, int position) {
        holder.bind(tasks.get(position), listener);
    }

    @Override
    public int getItemCount() {
        return tasks.size();
    }

    // ─── ViewHolder ──────────────────────────────────────────────────────

    static class TaskViewHolder extends RecyclerView.ViewHolder {

        private final CheckBox checkboxTask;
        private final TextView tvTaskTitle;

        TaskViewHolder(View itemView) {
            super(itemView);
            checkboxTask = itemView.findViewById(R.id.checkboxTask);
            tvTaskTitle  = itemView.findViewById(R.id.tvTaskTitle);
        }

        void bind(TaskManager.Task task, OnTaskChangedListener listener) {
            tvTaskTitle.setText(task.title);

            // تنسيق النص: شطب إذا مكتملة، طبيعي إذا لا
            if (task.completed) {
                tvTaskTitle.setPaintFlags(
                    tvTaskTitle.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG
                );
                tvTaskTitle.setAlpha(0.45f);
            } else {
                tvTaskTitle.setPaintFlags(
                    tvTaskTitle.getPaintFlags() & ~Paint.STRIKE_THRU_TEXT_FLAG
                );
                tvTaskTitle.setAlpha(1.0f);
            }

            // مهم: إزالة الـ listener قبل setChecked لتجنب trigger مزدوج
            checkboxTask.setOnCheckedChangeListener(null);
            checkboxTask.setChecked(task.completed);
            checkboxTask.setOnCheckedChangeListener(
                (btn, isChecked) -> listener.onTaskChanged(task.id, isChecked)
            );
        }
    }
}
