package com.fitness.motivator.service;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.app.usage.UsageStats;
import android.app.usage.UsageStatsManager;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.util.Log;

import androidx.core.app.NotificationCompat;

import com.fitness.motivator.ui.MainActivity;
import com.fitness.motivator.ui.OverlayActivity;
import com.fitness.motivator.utils.TaskManager;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.SortedMap;
import java.util.TreeMap;

/**
 * خدمة الخلفية — تراقب التطبيق النشط كل ثانية
 * وتُطلق شاشة الحجب عند فتح تطبيق ممنوع قبل إنجاز المهام
 */
public class AppMonitorService extends Service {

    private static final String TAG            = "AppMonitorService";
    private static final String CHANNEL_ID     = "fitness_monitor_channel";
    private static final int    NOTIFICATION_ID = 1001;
    private static final long   CHECK_INTERVAL  = 1000L; // كل ثانية

    /** قائمة التطبيقات المحجوبة */
    private static final Set<String> BLOCKED_APPS = new HashSet<>(Arrays.asList(
        "com.facebook.katana",        // Facebook
        "com.facebook.lite",          // Facebook Lite
        "com.zhiliaoapp.musically",   // TikTok
        "com.ss.android.ugc.trill",   // TikTok (نسخة أخرى)
        "com.instagram.android",      // Instagram
        "com.twitter.android",        // Twitter / X
        "com.twitter.lite",
        "com.snapchat.android",       // Snapchat
        "com.whatsapp",               // WhatsApp
        "com.telegram.messenger",     // Telegram
        "com.youtube.android",        // YouTube
        "com.google.android.youtube"
    ));

    public static boolean isRunning       = false;

    private Handler      handler;
    private Runnable     monitorRunnable;
    private TaskManager  taskManager;
    private String       lastBlockedApp   = "";
    private boolean      overlayShowing   = false;

    // ─── دورة حياة الخدمة ───────────────────────────────────────────────

    @Override
    public void onCreate() {
        super.onCreate();
        handler     = new Handler(Looper.getMainLooper());
        taskManager = new TaskManager(this);
        createNotificationChannel();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        startForeground(NOTIFICATION_ID, buildNotification());
        isRunning = true;
        startMonitorLoop();
        Log.d(TAG, "Service started ✅");
        return START_STICKY; // تُعاد تلقائياً إذا أُوقفت
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        isRunning = false;
        if (handler != null && monitorRunnable != null) {
            handler.removeCallbacks(monitorRunnable);
        }
        Log.d(TAG, "Service stopped");
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null; // لا نحتاج binding
    }

    // ─── حلقة المراقبة ───────────────────────────────────────────────────

    private void startMonitorLoop() {
        monitorRunnable = new Runnable() {
            @Override
            public void run() {
                checkForegroundApp();
                handler.postDelayed(this, CHECK_INTERVAL);
            }
        };
        handler.post(monitorRunnable);
    }

    private void checkForegroundApp() {
        String foregroundPkg = getForegroundPackage();
        if (foregroundPkg == null || foregroundPkg.isEmpty()) return;

        // تحديث حالة المهام في كل دورة
        taskManager = new TaskManager(this);

        boolean isBlocked      = BLOCKED_APPS.contains(foregroundPkg);
        boolean tasksIncomplete = !taskManager.areAllTasksCompleted();

        if (isBlocked && tasksIncomplete) {
            // يجب الحجب
            if (!overlayShowing || !foregroundPkg.equals(lastBlockedApp)) {
                lastBlockedApp = foregroundPkg;
                overlayShowing = true;
                launchOverlay(foregroundPkg);
                Log.d(TAG, "Blocked: " + foregroundPkg);
            }
        } else {
            overlayShowing = false;
            lastBlockedApp = "";
        }
    }

    /**
     * يستخدم UsageStatsManager لمعرفة آخر تطبيق نشط
     */
    private String getForegroundPackage() {
        try {
            UsageStatsManager usm =
                (UsageStatsManager) getSystemService(Context.USAGE_STATS_SERVICE);
            if (usm == null) return null;

            long now   = System.currentTimeMillis();
            long start = now - 5000; // آخر 5 ثوانٍ

            List<UsageStats> stats = usm.queryUsageStats(
                UsageStatsManager.INTERVAL_DAILY, start, now
            );

            if (stats == null || stats.isEmpty()) return null;

            // نأخذ التطبيق الأحدث استخداماً
            SortedMap<Long, UsageStats> sorted = new TreeMap<>();
            for (UsageStats s : stats) {
                sorted.put(s.getLastTimeUsed(), s);
            }

            String pkg = sorted.get(sorted.lastKey()).getPackageName();

            // تجاهل تطبيقنا نفسه
            return pkg.equals(getPackageName()) ? null : pkg;

        } catch (Exception e) {
            Log.e(TAG, "getForegroundPackage error: " + e.getMessage());
            return null;
        }
    }

    /**
     * إطلاق Activity الحجب فوق التطبيق المحجوب
     */
    private void launchOverlay(String blockedPackage) {
        Intent overlayIntent = new Intent(this, OverlayActivity.class);
        overlayIntent.addFlags(
            Intent.FLAG_ACTIVITY_NEW_TASK     |
            Intent.FLAG_ACTIVITY_SINGLE_TOP   |
            Intent.FLAG_ACTIVITY_NO_ANIMATION
        );
        overlayIntent.putExtra("blocked_package", blockedPackage);
        startActivity(overlayIntent);
    }

    // ─── الإشعار الدائم ──────────────────────────────────────────────────

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel ch = new NotificationChannel(
                CHANNEL_ID,
                "مراقب اللياقة",
                NotificationManager.IMPORTANCE_LOW
            );
            ch.setDescription("يراقب التطبيقات لحمايتك من الإدمان");
            ch.setShowBadge(false);
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(ch);
        }
    }

    private Notification buildNotification() {
        Intent mainIntent = new Intent(this, MainActivity.class);
        PendingIntent pi  = PendingIntent.getActivity(
            this, 0, mainIntent,
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        return new NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("💪 محفز اللياقة يعمل")
            .setContentText("يحمي تركيزك حتى تنهي مهامك اليومية")
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setContentIntent(pi)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build();
    }
}
